#include "stdafx.h"
#include "CppUnitTest.h"
#include "TrinomialPrice.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace UnitTest
{		
	TEST_CLASS(UnitTest1)
	{
	public:

		TEST_METHOD(Lattice)
		{
			Option opt(100.0, 100.0, 0.05, 0.30, 1, European, Call);
			TrinomialPrice p(&opt, 5);
			p.buildLattice(0);
			Assert::IsTrue(p.lattice->root->up->up->up->down->down ==
				p.lattice->root->down->down->up->up->up);
			Assert::IsTrue(p.lattice->root->up->down->down->horizontal->horizontal ==
				p.lattice->root->down->down->down->up->up);
		}

		TEST_METHOD(EuropeanCall5Step)
		{
			Option opt(100.0, 100.0, 0.05, 0.30, 1, European, Call);
			TrinomialPrice p(&opt, 5);
			p.buildLattice(0);
			p.backwardEval(p.lattice->root);
			Assert::AreEqual(14.22, p.lattice->root->data.optionPrice, 0.01);
		}

		TEST_METHOD(EuropeanPut5Step)
		{
			Option opt(100.0, 100.0, 0.05, 0.30, 1, European, Put);
			TrinomialPrice p(&opt, 5);
			p.buildLattice(0);
			p.backwardEval(p.lattice->root);
			Assert::AreEqual(9.34, p.lattice->root->data.optionPrice, 0.01);
		}

		TEST_METHOD(AmericanCall5Step)
		{
			Option opt(100.0, 100.0, 0.05, 0.30, 1, American, Call);
			TrinomialPrice p(&opt, 5);
			p.buildLattice(0);
			p.backwardEval(p.lattice->root);
			Assert::AreEqual(14.22, p.lattice->root->data.optionPrice, 0.01);
		}

		TEST_METHOD(AmericanPut5Step)
		{
			Option opt(100.0, 120.0, 0.05, 0.30, 1, American, Put);
			TrinomialPrice p(&opt, 5);
			p.buildLattice(0);
			p.backwardEval(p.lattice->root);
			Assert::AreEqual(22.82, p.lattice->root->data.optionPrice, 0.01);
		}
	};
}